import React, { useState, useEffect } from "react";
import { Container, Table } from "react-bootstrap";
import "./Dashboard.css";
// import Home from "../../Components/Nav/Home";
// import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  // const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));
  const Id = user?._id;
  const Name = user?.name;
  const Email = user?.email;
  const [products, setProducts] = useState([]);
  const [vendors, setVendors] = useState([]);

  // Hardcoded data
  const hardcodedProducts = [
    {
      medicine: { Name: "Medicine A", description: "Description for Medicine A" },
      manDate: "2023-01-01",
      expiryDate: "2024-01-01",
      units: 100,
      price: 50,
      valid: true,
      distributor: "Distributor A",
      production: "Production A",
    },
    {
      medicine: { Name: "Medicine B", description: "Description for Medicine B" },
      manDate: "2023-02-01",
      expiryDate: "2024-02-01",
      units: 50,
      price: 25,
      valid: true,
      distributor: "Distributor B",
      production: "Production B",
    },
    {
      medicine: { Name: "Medicine C", description: "Description for Medicine C" },
      manDate: "2023-01-01",
      expiryDate: "2024-01-01",
      units: 100,
      price: 50,
      valid: true,
      distributor: "Distributor C",
      production: "Production C",
    },
    {
      medicine: { Name: "Medicine D", description: "Description for Medicine D" },
      manDate: "2023-01-01",
      expiryDate: "2024-01-01",
      units: 100,
      price: 50,
      valid: true,
      distributor: "Distributor D",
      production: "Production D",
    },
    {
      medicine: { Name: "Medicine E", description: "Description for Medicine C" },
      manDate: "2023-01-01",
      expiryDate: "2024-01-01",
      units: 100,
      price: 50,
      valid: true,
      distributor: "Distributor E",
      production: "Production E",
    },
    {
      medicine: { Name: "Medicine F", description: "Description for Medicine C" },
      manDate: "2023-01-01",
      expiryDate: "2024-01-01",
      units: 100,
      price: 50,
      valid: true,
      distributor: "Distributor F",
      production: "Production F",
    },
  ];

  const hardcodedVendors = [
    {
      Id: "1",
      Customer: { Name: "Customer A" },
      PurchasedUnits: 10,
      Stock: { Medicine: { Name: "Medicine A" } },
      Status: "Rejected",
    },
    {
      Id: "2",
      Customer: { Name: "Customer B" },
      PurchasedUnits: 5,
      Stock: { Medicine: { Name: "Medicine B" } },
      Status: "Accepted",
    },
    {
      Id: "3",
      Customer: { Name: "Customer C" },
      PurchasedUnits: 10,
      Stock: { Medicine: { Name: "Medicine C" } },
      Status: "Rejected",
    },
    {
      Id: "3",
      Customer: { Name: "Customer D" },
      PurchasedUnits: 5,
      Stock: { Medicine: { Name: "Medicine D" } },
      Status: "Accepted",
    },
    {
      Id: "4",
      Customer: { Name: "Customer E" },
      PurchasedUnits: 10,
      Stock: { Medicine: { Name: "Medicine E" } },
      Status: "Accepted",
    },
    {
      Id: "5",
      Customer: { Name: "Customer F" },
      PurchasedUnits: 5,
      Stock: { Medicine: { Name: "Medicine F" } },
      Status: "Accepted",
    },
    {
      Id: "6",
      Customer: { Name: "Customer G" },
      PurchasedUnits: 10,
      Stock: { Medicine: { Name: "Medicine G" } },
      Status: "Rejected",
    },
    {
      Id: "7",
      Customer: { Name: "Customer H" },
      PurchasedUnits: 5,
      Stock: { Medicine: { Name: "Medicine H" } },
      Status: "Accepted",
    },
  ];

  const update_acceptedOrder = (event, Status) => {
    event.Status = Status;
    // Simulate API call and update data
    setVendors((prevVendors) =>
      prevVendors.map((vendor) =>
        vendor.Id === event.Id ? { ...vendor, Status } : vendor
      )
    );
  };

  // const change = () => {
  //   navigate("/sell");
  // };

  useEffect(() => {
    // Use hardcoded data instead of API calls
    setProducts(hardcodedProducts);
    setVendors(hardcodedVendors);
  }, []);

  return (
    <div>
      <Container className="dashboard-container-fluid pr-5 pl-5 pt-5 pb-5">
      <Container className="dashboard-user-greeting mb-5">
  <div className="dashboard-user-info">
    <h1 className="dashboard-greeting-text">{Name}</h1>
    <h2 className="dashboard-user-id">{Id}</h2>
    <h2 className="dashboard-user-id">{Email}</h2>
  </div>
</Container>
        <Container className="dashboard-container-fluid my-3">
          <h2>Purchased Stock Summary</h2>
        </Container>
        <Container className="row d-flex  align-items-center">
          {!products.length}
          {products.length >= 0 &&
            products.map(({ units, medicine }) => (
              <Container key={medicine.Name} className="col-lg-4 col-sm-6 is-light-text mb-4">
                <Container className="dashboard-grid-card">
                  <Container className="dashboard-card-heading">
                    <Container
                      style={{ fontSize: 35, marginBottom: 10 }}
                    >
                      {medicine.Name}
                    </Container>
                    <Container>
                      {medicine.description}
                    </Container>
                  <Container className="pt-4">
                    No of Units: {units}
                  </Container>
                  </Container>

                </Container>
              </Container>
            ))}
        </Container>
      </Container>
    </div>
  );
};

export default Dashboard;