const server_url = "http://localhost:3001"

export default server_url;